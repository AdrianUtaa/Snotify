package com.Snotify.Snotifyechipa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnotifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnotifyApplication.class, args);
	}

}
