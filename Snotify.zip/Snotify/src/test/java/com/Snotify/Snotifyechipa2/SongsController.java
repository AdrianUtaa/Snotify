package com.Snotify.Snotifyechipa2;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class SongsController {

    private final SongsRepository repository;
    private SongModelAssembler assembler = null;
    SongsController(SongsRepository repository, SongModelAssembler assembler) {
        this.repository = repository;
        this.assembler = assembler;
    }


    // Aggregate root
    // tag::get-aggregate-root[]
    @GetMapping("/songs")
    List<Songs> all() {
        return repository.findAll();
    }
    // end::get-aggregate-root[]

    @PostMapping("/songs")
    Songs newSongs(@RequestBody Songs newSongs) {
        return repository.save(newSongs);
    }

    // Single item

    @GetMapping("/songs/{id}")
    Songs one(@PathVariable Long id) {

        return repository.findById(id)
                .orElseThrow(() -> new SongsNotFoundException(id));
    }

    @PutMapping("/songs/{id}")
    Songs replaceSongs(@RequestBody Songs newSongs, @PathVariable Long id) {

        return repository.findById(id)
                .map(song -> {
                    song.setTitle(newSongs.getTitle());
                    song.setSingers(newSongs.getSingers());
                    song.setReleaseYear(newSongs.getReleaseYear());
                    song.setGenre(newSongs.getGenre());
                    return repository.save(song);
                })
                .orElseGet(() -> {
                    newSongs.setId(id);
                    return repository.save(newSongs);
                });
    }

    @DeleteMapping("/songs/{id}")
    void deleteSongs(@PathVariable Long id) {
        repository.deleteById(id);
    }
}

