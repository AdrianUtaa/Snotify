package com.Snotify.Snotifyechipa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
@SpringBootApplication
public class SnotifyApplication {


        public static void main(String[] args) {
            SpringApplication.run(com.Snotify.Snotifyechipa2.SnotifyApplication.class, args);
        }

    }

