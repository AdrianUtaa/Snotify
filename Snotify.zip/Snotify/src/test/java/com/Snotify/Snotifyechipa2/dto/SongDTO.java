package com.Snotify.Snotifyechipa2.dto;

import javax.persistence.*;
import java.util.Objects;

public class SongDTO {




        private Long id;
        private String title;
        private String singers;
        private int releaseYear;
        private String genre;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSingers() {
            return singers;
        }

        public void setSingers(String singers) {
            this.singers = singers;
        }

        public int getReleaseYear() {
            return releaseYear;
        }

        public void setReleaseYear(int releaseYear) {
            this.releaseYear = releaseYear;
        }

        public String getGenre() {
            return genre;
        }

        public void setGenre(String genre) {
            this.genre = genre;
        }
        @Override
        public boolean equals(Object o) {

            if (this == o)
                return true;
            if (!(o instanceof SongDTO))
                return false;
            SongDTO songDTO = (SongDTO) o;
            return getReleaseYear() == songDTO.getReleaseYear() && Objects.equals(getId(), songDTO.getId()) && Objects.equals(getTitle(), songDTO.getTitle()) && Objects.equals(getSingers(), songDTO.getSingers()) && Objects.equals(getGenre(), songDTO.getGenre());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getId(), getTitle(), getSingers(), getReleaseYear(), getGenre());
        }
    }

