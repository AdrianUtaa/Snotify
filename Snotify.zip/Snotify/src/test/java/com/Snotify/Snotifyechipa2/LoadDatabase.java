package com.Snotify.Snotifyechipa2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Set;
@Configuration
class LoadDatabase {

    private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    CommandLineRunner initDatabase(SongsRepository repository) {

        return args -> {
            Songs song1 = new Songs("Girls Just Want To Have Fun", "Cyndi Lauper", 1983, "pop"  );
            Songs song2 = new Songs("Dynamite", "BTS", 2020, "pop");


            log.info("Preloading " + repository.save(song1));
            log.info("Preloading " + repository.save(song2));

        };
    }
}