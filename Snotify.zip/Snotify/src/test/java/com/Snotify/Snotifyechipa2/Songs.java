package com.Snotify.Snotifyechipa2;

import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name ="songs")
public class Songs {

    private @Id @GeneratedValue(strategy = GenerationType.AUTO) Long id;
    private String title;
    private String singers;
    private int releaseYear;
    private String genre;

    public Songs() {
        this.title = "null";
        this.genre = "null";
        this.releaseYear = 0;

    }
    public void setSingers(String singers) {
        this.singers = singers;
    }

    public Songs(String title, int releaseYear, String genre) {
        this.title = title;
        this.releaseYear = releaseYear;
        this.genre = genre;

    }
    public String getSingers() {
        return singers;
    }
    public Songs(Long id, String title, int releaseYear, String genre) {
        this.id = id;
        this.title = title;
        this.releaseYear = releaseYear;
        this.genre = genre;

    }
    public Songs(String title, String singers, int releaseYear, String genre) {
        this.title = title;
        this.singers = singers;
        this.releaseYear= releaseYear;
        this.genre= genre;
    }
    public String getTitle() {
        return title;
    }


    public int getReleaseYear() {
        return releaseYear;
    }

    public String getGenre() {
        return genre;
    }

    public Long getId() {
        return this.id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    //public void setSingers(List<String> singers) {
    //   this.singers = singers;
    // }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }



    public void setId(Long id) {
        this.id = id;
    }


    // @Override
    //public boolean equals(Object o) {
    //if (this == o) return true;
    //if (!(o instanceof Song)) return false;
    // Song song = (Song) o;
    //   return getReleaseYear() == song.getReleaseYear() && Objects.equals(getId(), song.getId()) && Objects.equals(getTitle(), song.getTitle()) && Objects.equals(getSingers(), song.getSingers()) && Objects.equals(getGenre(), song.getGenre());
    // }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTitle(),  getReleaseYear(), getGenre());
    }

    @Override
    public String toString() {
        return "Song{" +
                "id=" + id +
                ", title='" + title + '\'' +

                ", releaseYear=" + releaseYear +
                ", genre='" + genre + '\'' +
                '}';
    }
}