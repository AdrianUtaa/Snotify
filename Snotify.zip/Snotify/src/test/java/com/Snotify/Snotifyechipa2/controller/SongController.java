package com.Snotify.Snotifyechipa2.controller;
import com.Snotify.Snotifyechipa2.Songs;
import com.Snotify.Snotifyechipa2.dto.SongDTO;
import com.Snotify.Snotifyechipa2.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.apache.coyote.Response;

@RestController //Realizam o metoda POST(SongDTO songDTO)
public class SongController {
    @Autowired
    private SongService songService;

    /*@PostMapping("/songs")
    public ResponseEntity<Songs> addSong(@RequestBody SongDTO songDTO){
        return ResponseEntity.status(201).body(songService.addSong(songDTO));
    }*/


    public Songs POST(Songs songs) {
        SongDTO songDTO = new SongDTO();
        songDTO.setTitle(songs.getTitle());
        songDTO.setSingers(songs.getSingers());
        songDTO.setGenre(songs.getGenre());
        songDTO.setReleaseYear(songs.getReleaseYear());

        return songService.addSongs(songDTO);
    }
}


