package com.Snotify.Snotifyechipa2;

class SongsNotFoundException extends RuntimeException {
    SongsNotFoundException(Long id) {
        super("Could not find songs " + id);
    }
}
