package com.Snotify.Snotifyechipa2;

import  static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
@Component
public class SongModelAssembler implements RepresentationModelAssembler<Songs, EntityModel<Songs>> {


    @Override
    public EntityModel<Songs> toModel(Songs song) {

        return EntityModel.of(song, //
                linkTo(methodOn(SongsController.class).one(song.getId())).withSelfRel(),
                linkTo(methodOn(SongsController.class).all()).withRel("songs"));
    }


}





