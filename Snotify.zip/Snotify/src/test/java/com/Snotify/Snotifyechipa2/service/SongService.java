package com.Snotify.Snotifyechipa2.service;

import com.Snotify.Snotifyechipa2.Songs;
import com.Snotify.Snotifyechipa2.SongsRepository;
import com.Snotify.Snotifyechipa2.dto.SongDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class SongService {
    @Autowired
    private SongsRepository songsRepository;

    public  Songs addSongs(SongDTO songDTOg){
        Songs songs = new Songs();
        songs.setGenre(songDTOg.getGenre());
        songs.setTitle(songDTOg.getTitle());
        songs.setSingers(songDTOg.getSingers());
        songs.setReleaseYear(songDTOg.getReleaseYear());

        return  songsRepository.save(songs);
    }




}

